// TODO 1
class Cat(private val name: String) {
    var sleep: Boolean = false
        get() = field
        set(value) {
            field = value
        }

    fun toSleep() {
        println(if(sleep)"$name, sleep!" else "$name, let's play!")
    }
}

fun main() {

    // TODO 2
    val gippy = Cat("Gippy")

    println("Fungsi getter dipanggil")
    gippy.toSleep()
    println("Fungsi setter dipanggil")
    gippy.sleep = true
    println("Fungsi getter dipanggil")
    gippy.toSleep()
}