fun main() {
    val text: String? = null
    text?.length
}